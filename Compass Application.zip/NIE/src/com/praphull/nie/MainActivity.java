package com.praphull.nie;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.Activity;

public class MainActivity extends Activity implements SensorEventListener {

	// define the display assembly compass picture
	private ImageView compass;
	
	//record the compass picture angle turned 
	private float currentDegree = 0f;
	
	// device sensor manager
	private SensorManager mSensorManager;
	
	TextView heading;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //our compass image 
        compass = (ImageView) findViewById(R.id.imagecampassview);
        
        //TextView that will tell the user what degree is a heading
        heading = (TextView) findViewById(R.id.tvheading);
        
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
    }
    
    
	@Override
	protected void onResume(){
		super.onResume();
		
		mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), 
				SensorManager.SENSOR_DELAY_GAME);
				
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		mSensorManager.unregisterListener(this);
		
	}
	
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		
		float degree=Math.round(event.values[0]);
		
		heading.setText("Heading: " + Float.toString(degree) + "degrees");
		
		RotateAnimation ra = new RotateAnimation(
				currentDegree,
				-degree,
				Animation.RELATIVE_TO_SELF, 0.5f,
				Animation.RELATIVE_TO_SELF, 0.5f);
		
	ra.setDuration(210);
	
	ra.setFillAfter(true);
	
	compass.startAnimation(ra);
	currentDegree= -degree;
	}
}
